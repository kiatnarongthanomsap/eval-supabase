import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-score-adjustments.ts';