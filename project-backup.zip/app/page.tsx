export default function Home() {
  // The main application logic is now in AppShell, which is rendered by the root layout.
  // This file is kept to satisfy Next.js routing structure but the content is handled in layout.tsx.
  return null;
}
